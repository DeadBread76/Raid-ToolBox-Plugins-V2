import os
import sys
import ast
import json
import time
import requests
from concurrent.futures import ThreadPoolExecutor
sys.path.append(os.getcwd())
import plugins.helper

if not sys.platform.startswith('darwin'):
    import PySimpleGUI as sg
else:
    import PySimpleGUIQt as sg

theme = ast.literal_eval(sys.argv[1])
if theme['use_custom_theme']:
    sg.SetOptions(background_color=theme['background_color'],
                 text_element_background_color=theme['text_element_background_color'],
                 element_background_color=theme['element_background_color'],
                 scrollbar_color=theme['scrollbar_color'],
                 input_elements_background_color=theme['input_elements_background_color'],
                 input_text_color=theme['input_text_color'],
                 button_color=theme['button_colour'],
                 text_color=theme['text_color'])
else:
    sg.ChangeLookAndFeel(theme['preset_theme'])

token_list = plugins.helper.token_list
threadcount = plugins.helper.thread_count
tokenlist = open(f"./tokens/{token_list}").read().splitlines()
executor = ThreadPoolExecutor(max_workers=int(threadcount))


def ping(token, channel, server):
    headers, proxies = plugins.helper.setup_request(token)
    if channelid == 'all':
        while True:
            try:
                src = request.get(f"https://canary.discordapp.com/api/v6/guilds/{server}/channels",headers=headers, proxies=proxies, timeout=10)
            except Exception:
                if use_proxies == 1:
                    proxies = request_new_proxy()
                else:
                    break
            else:
                break
        if src.status_code == 401:
            error = json.loads(src.content)
            plugins.helper.write_error(token, error['message'], error['code'])
            sys.exit()
        elif src.status_code == 404:
            error = json.loads(src.content)
            plugins.helper.write_error(token, error['message'], error['code'])
            sys.exit()
        elif src.status_code == 403:
            error = json.loads(src.content)
            plugins.helper.write_error(token, error['message'], error['code'])
            sys.exit()
        channellist = json.loads(src.content)
        while True:
            for channel in channellist:
                payload = {"content": "@everyone", "tts": False}
                if not channel['type'] == 0:
                    continue
                else:
                    while True:
                        try:
                            src = request.post(f"https://canary.discordapp.com/api/v6/channels/{channel['id']}/messages", headers=headers, json=payload, proxies=proxies, timeout=10)
                        except Exception:
                            if use_proxies == 1:
                                proxies = request_new_proxy()
                            else:
                                break
                        else:
                            break
                    if src.status_code == 429:
                        ratelimit = json.loads(src.content)
                        time.sleep(float(ratelimit['retry_after']/1000))
                    elif src.status_code == 401:
                        error = json.loads(src.content)
                        plugins.helper.write_error(token, error['message'], error['code'])
                        sys.exit()
                    elif src.status_code == 404:
                        error = json.loads(src.content)
                        plugins.helper.write_error(token, error['message'], error['code'])
                        sys.exit()
                    elif src.status_code == 403:
                        error = json.loads(src.content)
                        plugins.helper.write_error(token, error['message'], error['code'])
                    else:
                        while True:
                            try:
                                requests.delete(f"https://canary.discordapp.com/api/v6/channels/{channel['id']}/messages/{src.json()['id']}", headers=headers, proxies=proxies, timeout=10)
                            except Exception:
                                if use_proxies == 1:
                                    proxies = request_new_proxy()
                                else:
                                    break
                            else:
                                break
    else:
        while True:
            payload = {"content": "@everyone", "tts": False}
            while True:
                try:
                    src = request.post(f"https://canary.discordapp.com/api/v6/channels/{channel}/messages", headers=headers, json=payload, proxies=proxies, timeout=10)
                except Exception:
                    if use_proxies == 1:
                        proxies = request_new_proxy()
                    else:
                        break
                else:
                    break
            if src.status_code == 429:
                ratelimit = json.loads(src.content)
                time.sleep(float(ratelimit['retry_after']/1000))
            elif src.status_code == 401:
                error = json.loads(src.content)
                plugins.helper.write_error(token, error['message'], error['code'])
                sys.exit()
            elif src.status_code == 404:
                error = json.loads(src.content)
                plugins.helper.write_error(token, error['message'], error['code'])
                sys.exit()
            elif src.status_code == 403:
                error = json.loads(src.content)
                plugins.helper.write_error(token, error['message'], error['code'])
            else:
                while True:
                    try:
                        requests.delete(f"https://canary.discordapp.com/api/v6/channels/{channel['id']}/messages/{channel}", headers=headers, proxies=proxies, timeout=10)
                    except Exception:
                        if use_proxies == 1:
                            proxies = request_new_proxy()
                        else:
                            break
                    else:
                        break

layout = [
        [sg.Text('Ghost Ping Spammer Example Plugin')],
        [sg.Text('Channel ID', size=(15, 1)), sg.Input('all', key="ChannelID")],
        [sg.Text('Server ID', size=(15, 1)), sg.Input(key="ServerID")],
        [sg.RButton('Start', button_color=theme['button_colour'], size=(10, 1))]
        ]
window = sg.Window('RTB | Ghost Ping Spammer', layout, keep_on_top=True)
event, values = window.Read()
window.Close()
if event == "Start":
    channelid = values["ChannelID"]
    SERVER = values["ServerID"]
else:
    sys.exit()

for token in tokenlist:
    executor.submit(ping, token, channelid, SERVER)
