import sys
import ast
import json
import requests
import threading

if not sys.platform.startswith('darwin'):
    import PySimpleGUI as sg
else:
    import PySimpleGUIQt as sg

theme = ast.literal_eval(sys.argv[1])
if theme['use_custom_theme']:
    sg.SetOptions(background_color=theme['background_color'],
                 text_element_background_color=theme['text_element_background_color'],
                 element_background_color=theme['element_background_color'],
                 scrollbar_color=theme['scrollbar_color'],
                 input_elements_background_color=theme['input_elements_background_color'],
                 input_text_color=theme['input_text_color'],
                 button_color=theme['button_colour'],
                 text_color=theme['text_color'])
else:
    sg.ChangeLookAndFeel(theme['preset_theme'])

def check():
    try:
        tokenlist = open(values["Token List"]).read().splitlines()
        for token in tokenlist:
            headers = {'Authorization': token.rstrip(), 'Content-Type': 'application/json', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/0.0.305 Chrome/69.0.3497.128 Electron/4.0.8 Safari/537.36'}
            src = requests.get('https://canary.discordapp.com/api/v6/users/@me', headers=headers)
            if "401: Unauthorized" in str(src.content):
                print("Unable to login to token.")
                continue
            else:
                src = requests.get("https://canary.discordapp.com/api/v6/users/@me/entitlements/gifts", headers=headers)
                s = json.loads(src.content)
                print("{token} - {giftcount} Gift(s)".format(token=token, giftcount=len(s)))
        print("Finished Job for {listname}".format(listname=values["Token List"]))
    except Exception as e:
        print(e)
    window.FindElement('Start').Update(disabled=False)
    window.FindElement('Browse').Update(disabled=False)

layout = [
        [sg.Text('Bulk Nitro Gift Checker')],
        [sg.Input("Select a token list...", key="Token List"), sg.FileBrowse(button_color=theme['button_colour'],size=(10,1), key="Browse", file_types=(("Token Lists", "*.txt"),))],
        [sg.Output(size=(80, 15))],
        [sg.Button('Start', button_color=theme['button_colour'],size=(10,1), key="Start")]
        ]
window = sg.Window('RTB Plugin | Bulk Nitro Gift Checker', layout, keep_on_top=True)
while True:
    event, values = window.Read(timeout=10)
    if event == "Start":
        t = threading.Thread(name='Check Tokens', target=check)
        t.start()
        window.FindElement('Start').Update(disabled=True)
        window.FindElement('Browse').Update(disabled=True)
    elif event == sg.TIMEOUT_KEY:
        window.Refresh()
    elif event is None:
        sys.exit()
