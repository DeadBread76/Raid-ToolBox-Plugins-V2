import os
import sys
import ast
import json
import requests
import threading
sys.path.append(os.getcwd())
import plugins.helper
from concurrent.futures import ThreadPoolExecutor
printqueue = []
if not sys.platform.startswith('darwin'):
    import PySimpleGUI as sg
else:
    import PySimpleGUIQt as sg

theme = ast.literal_eval(sys.argv[1])
if theme['use_custom_theme']:
    sg.SetOptions(background_color=theme['background_color'],
                 text_element_background_color=theme['text_element_background_color'],
                 element_background_color=theme['element_background_color'],
                 scrollbar_color=theme['scrollbar_color'],
                 input_elements_background_color=theme['input_elements_background_color'],
                 input_text_color=theme['input_text_color'],
                 button_color=theme['button_colour'],
                 text_color=theme['text_color'])
else:
    sg.ChangeLookAndFeel(theme['preset_theme'])
s = requests.Session()

def check_token(token):
    headers, proxies = plugins.helper.setup_request(token)
    while True:
        try:
            src = s.get('https://canary.discordapp.com/api/v6/users/@me', headers=headers, proxies=proxies, timeout=10)
        except Exception:
            if plugins.helper.use_proxies == 1:
                proxies = plugins.helper.request_new_proxy()
            else:
                break
        else:
            break
    if src.status_code == 401:
        printqueue.append("Unable to login to token.")
    else:
        while True:
            try:
                src = s.get("https://canary.discordapp.com/api/v6/users/@me/entitlements/gifts", headers=headers, proxies=proxies, timeout=10)
            except Exception:
                if plugins.helper.use_proxies == 1:
                    proxies = plugins.helper.request_new_proxy()
                else:
                    break
            else:
                break
        printqueue.append(f"{token} - {len(src.json())} Gift(s)")

def check():
    try:
        tokenlist = open(values["Token List"]).read().splitlines()
        with ThreadPoolExecutor(max_workers=4) as executor:
            for token in tokenlist:
                executor.submit(check_token, token.rstrip())
        printqueue.append(f"Finished Job for {values['Token List']}")
    except Exception as e:
        printqueue.append(e)
    window['Start'].Update(disabled=False)
    window['Browse'].Update(disabled=False)

layout = [
    [sg.Text('Bulk Nitro Gift Checker')],
    [sg.Input("Select a token list...", key="Token List"), sg.FileBrowse(button_color=theme['button_colour'],size=(10,1), key="Browse", file_types=(("Token Lists", "*.txt"),))],
    [sg.Output(size=(80, 15))],
    [sg.Button('Start', button_color=theme['button_colour'],size=(10,1), key="Start")]
]
window = sg.Window('RTB Plugin | Bulk Nitro Gift Checker', layout, keep_on_top=True)
while True:
    event, values = window.Read(timeout=10)
    if event == "Start":
        threading.Thread(name='Check Tokens', target=check, daemon=True).start()
        window['Start'].Update(disabled=True)
        window['Browse'].Update(disabled=True)
    elif event == sg.TIMEOUT_KEY:
        for p in printqueue:
            print(p)
            printqueue.remove(p)
        window.Refresh()
    elif event is None:
        sys.exit()
